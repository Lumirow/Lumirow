module.exports = {
  root: true,
  extends: ['animeflix'],
};
